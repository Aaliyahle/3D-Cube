document.querySelector('.scene').addEventListener('mousemove', function(e) {
    const cube = document.querySelector('.cube');
    let xAxis = (window.innerWidth / 2 - e.pageX) / 20;
    let yAxis = (window.innerHeight / 2 - e.pageY) / 20;
    cube.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
});
